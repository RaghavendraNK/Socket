let express = require("express");
let appConfig = require("./appConfig.json");
let path = require("path");
let logger = require("morgan");
let bodyParser = require("body-parser");
let neo4j = require("neo4j-driver").v1;
let cors = require("cors")
let fs = require("fs");
let http = require("http");
let app=express();
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(logger("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, "public")));
app.use(cors());
let _ = require('lodash');
let driver =  neo4j.driver(appConfig.URL, neo4j.auth.basic(appConfig.USER_NAME, appConfig.PASSWORD));
let session = driver.session();
let httpServer = http.createServer(app);
let io = require("socket.io").listen(httpServer);

io.on("connection", function(socket) {
  socket.on("isInProgressNodesModification", (interval) => {
    setInterval(() => {
    session
      .run("MATCH (n:IS_INPROGRESS) RETURN n")
      .then(function(result){
          socket.emit("flag", {data:result.records[0]});
      })
      .catch(function(error){
          socket.emit("flag", {error: error});
      });
    }, interval);
  });
});

app.get("/getRemovedNodes", function(req, res){
     Promise.all([
           session.run("MATCH (D:VISDELNODEQUEUE) RETURN D.DELNODEIDS"),
           session.run("MATCH (D:VISDELNODEQUEUE) SET D.DELNODEIDS=[]"),
           session.run("MATCH (a:UE),(b:UEDELETED),(c:NR) return (a.count+b.count) as supConnection,count(c) as NRCount")
      ])
      .then((results) => {

        let _result = {
         "removeNodes": results[0].records,
         "count": 200///results[2].records
        };
        res.send(_result);
        session.close();
      })
      .catch(function (error) {
          res.status(500).send({error: error});
          session.close();
      });
});

app.get("/getNodes", function(req, res){
    Promise.all([
          session.run("MATCH (n) where not (n:IS_INPROGRESS) OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m"),
          session.run("MATCH (a:UE),(b:UEDELETED),(c:NR) return (a.count+b.count) as supConnection,count(c) as NRCount")
     ])
    .then(function (result) {
      let _count = result[1].records && result[1].records.length>0 && result[1].records[0]._fieldLookup  ? result[1].records[0]._fieldLookup : {"supConnection": 0, "NRCount": 0}
      let _obj = {
        "nodes": result[0].records,
        "count": _count
      };
    res.send(_obj);
    session.close();
  })
  .catch(function (error) {
      res.status(500).send({error: error});
      session.close();
  });
});

app.get("/getInitalNodes", function(req, res){
    Promise.all([
          session.run("MATCH (n) where not (n:IS_INPROGRESS) OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m"),
          session.run("MATCH (D:IS_INPROGRESS) SET D.refresh=false")
     ])
    .then(function (result) {
    res.send(result[0].records);
    session.close();
  })
  .catch(function (error) {
      res.status(500).send({error: error});
      session.close();
  });
});
app.get("/updatePause/:flag", function(req, res){
session.run(`MATCH (D:IS_INPROGRESS) SET D.pause=${req.params.flag}`)
    .then(function (result) {
    res.send("Success");
    session.close();
  })
  .catch(function (error) {
      res.status(500).send({error: error});
      session.close();
  });
});
app.get("/getLatestNodes/:maxId", function(req, res){
      session
        .run(`MATCH (n) where toInt(n.id)>toInt (${req.params.maxId}) OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m`)
        ///.run("MATCH (n) where not (n:IS_INPROGRESS) OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m")
        .then(function (result) {
        res.send(result.records);
        session.close();
      })
      .catch(function (error) {
          res.status(500).send({error: error});
          session.close();
      });
});


httpServer.listen(appConfig.PORT);
console.log(`Server started on Port ${appConfig.PORT}`);
module.exports=app;
