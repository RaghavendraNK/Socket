import _ from "lodash";

export let filterNodes = (nodesList) => {
  let _nodes =[], _nodesList = getNodesData(nodesList);
  _nodesList && _nodesList.map((node, index)=>{
    if(node)
      return _nodes.push(node.properties);
    return;
  });
  return _nodes;
}


export let optimizeNodes = (nodes, removenodes) => {
  if(removenodes && removenodes.length>0){
    let _nodes = _.reject(nodes, function(p){
          return _.find((_.flattenDepth(removenodes, 1)), function(o){
            return o == p.id;
          });
    });
    return _nodes;
  }else{
    return nodes;
  }
}

export let getGroup = (nodesList, pnode) => {
  let _groupId = "", _nodesList = getNodesData(nodesList);
  return _groupId = _nodesList && _nodesList.find((node, index)=>{
     return node.properties.id==pnode.id;
  });
}

export let filterEdges = (nodesList) => {
  let _nodes =[], _nodesList =  filterNodes(nodesList);
  _nodesList && _nodesList.map((node, index)=>{
      let _n = node;
      return node && node.from && node.from.map((f, index)=>{
        return _nodes.push({from: f, to: _n.to[index], arrows:{ to: { enabled: false, type: "" } } });
      });
  });
  return _nodes;
}

export let getNodesData = (nodesList) => {
  let _nodes = [];
  nodesList && nodesList.data.map((node, index)=>{
      node._fields = _.filter(node._fields, function(o) { return o!=null; });
      if(node._fields && node._fields.length>=3 && node._fields[1].type=="ConnectedWith"){
        node._fields[0].properties.from=[node._fields[0].properties.id];
        node._fields[0].properties.to=[node._fields[2].properties.id];
       _nodes.push([node._fields[0]]);
     }else{
       if(node._fields[0] && node._fields[0].properties){
         let { id, ip, priority } = node._fields[0].properties;
         let _prop = {
           id: id,
           ip: ip,
           from: [],
           to: [],
           priority: priority
         }
         node._fields[0].properties =_prop;
         _nodes.push([node._fields[0]]);
       }
     }
  });
  let _nodesWithIdentity = [];
  _nodesWithIdentity = _.filter((_.flattenDepth(_nodes, 1)), function(o) { return o!=null; });
  return _.filter(_nodesWithIdentity, function(o) { return o.properties && o.properties.id!=undefined && o.properties.id!=null; });
}

export let modifyProps =  (nodesList, removeNodes) => {
  let _filteredList = filterNodes(nodesList);
  let _optimizedNodes = _.uniqWith((optimizeNodes(_filteredList, removeNodes)), _.isEqual);
  let _nodes = [];
  _optimizedNodes && _optimizedNodes.map((node, index)=>{
        let _getGroup = getGroup(nodesList, node);
        let _groupId = _getGroup? _getGroup.labels[0]: "";
        return _nodes.push({id: node.id, label:"", priority:node.priority, group:_groupId, title: `<div><span><strong>Id: </strong></span><span>${node.id}</span><br/><span><strong>Ip: </strong></span><span>${node.ip}</span></div>`});
  });
  return _nodes;
}
