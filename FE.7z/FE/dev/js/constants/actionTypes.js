/// Action Type for the Get Nodes
export const GET_NODES = "GET_NODES"
export const UPDATE_NODES="UPDATE_NODES"
