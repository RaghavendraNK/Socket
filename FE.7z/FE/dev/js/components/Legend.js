/* react builtin libraries */
import React, {Component} from "react";
/* redux builtin libraries for connecting the component with action*/
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
/* Make the API Call to get the Nodes */
/* Get the configurations from config file */
import {appConfig} from "../config/appConfig.json";
import {suspendOrResume} from "../actions/nodesActions";
/* Contains the different node classes */
const nodeList = appConfig.NODE_LIST;

class Legend extends Component{
  constructor(props){
    super(props);
    this.state= {
        _ueCount: props.count,
        serviceStatus: false
    }
  }

  suspendOrResume(flag){
      this.props.suspendOrResume(flag).then(()=>{
        this.setState({serviceStatus: flag});
      }).catch((error)=>{
        console.log("catch");
      });
  }

  getImage(node){
    switch (node) {
      case "NR": return "assets/images/nrDb.svg";
      case "SUPI": return "assets/images/supiDb.svg";
      case "UDM": return "assets/images/udmDb.svg";
      case "AUSF": return "assets/images/ausfDb.svg";
      case "RAN": return "assets/images/ranDb.svg";
      default: return "assets/images/nrDb.svg";
    }
  }

  getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }


  getCount(node){
    let _UECount = this.state._ueCount;
    let _nodeObj = _.find(appConfig.COUNT, ['key', node]);
    let _count = parseInt(_UECount.supConnection) - (parseInt(_UECount.supConnection) * (parseInt(_nodeObj.value) / 100));
    switch (node) {
      case "NR": return `NR: ${_UECount.NRCount}`;
      case "SUPI": return `SUPI: ${parseInt(_UECount.supConnection)}`;
      case "UDM": return `UDM: ${this.getRandomInt(1, 2)}`;
      case "AUSF": return `AUSF: ${this.getRandomInt(1, 2)}`;
      case "RAN": return `RAN: ${_count}`;
      default: return "";
    }
  }

  componentWillReceiveProps(nextProps) {
    if(this.props && nextProps && this.props.count!=nextProps.count){
      this.setState({_ueCount: nextProps.count});
    }
  }
  render(){
  return(
          <div className="row">
            <div className="col-md-12">
            {/*<div className="float-left" style={{"margin-top":"6px","margin-left":"10px"}}>
            <div className="txt-center">
                    {this.state.serviceStatus && <img className="cursor-pointer mar-5px hvr-bounce-in" width="30" height="30" src="assets/images/play.svg" onClick={this.suspendOrResume.bind(this, false)} />}
                    {!this.state.serviceStatus && <img className="cursor-pointer mar-5px hvr-bounce-in" width="30" height="30" src="assets/images/pause.svg" onClick={this.suspendOrResume.bind(this, true)} />}
             </div>
            </div>*/}
                <div className="float-right" style={{"marginRight":"20px"}}>
                  {nodeList && nodeList.map((node, index)=>{
                      return (<div key={"node_legend"+index} className="hvr-bounce-in">
                                    <div className="customTooltip"><img className="node-l" src={this.getImage(node)} /> <span className="tooltiptext">{this.getCount(node)}</span></div>
                              </div>);
                  })}
                </div>
            </div>
          </div>
         );
  }
}

Legend.contextTypes = {
  router: React.PropTypes.object.isRequired
};

function mapStateToProps(state) {
    return {
      count: state.nodes? state.nodes.count: {"supConnection": 0, "NRCount": 0}
    };
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({suspendOrResume}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(Legend);
