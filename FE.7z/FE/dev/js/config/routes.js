/* react builtin libraries */
import React from "react";
import {Router, Route, IndexRoute} from "react-router";

/* containers */
import App from "../containers/app";
import Home from "../containers/home";

export default(
  <Route path="/" component={App}>
    <IndexRoute component={Home} />
    <Route path="/home" component={Home} />
  </Route>
);
