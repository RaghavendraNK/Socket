/* react builtin libraries */
import React, {Component} from "react";
/* redux builtin libraries for connecting the component with action*/
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
/* Make the API Call to get the Nodes */
import {getNodes} from "../actions/nodesActions";

/* Get the configurations from config file */
import {appConfig} from "../config/appConfig.json";
import Legend from "../components/Legend";

class App extends Component{
  constructor(props){
    super(props);
  }

  componentWillMount(){
    this.props.getNodes().then(()=>{
    }).catch((error)=>{
      console.error(error);
    });
  }

  render(){
  return(<div className="container-fluid">
         {/* Header Section Start*/}
          <div className="row bgGrey">
            <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4">
              <img className="logo" src="./assets/images/logo.png" />
            </div>
          </div>
          {/* Header Section End*/}
          {/* Container Section Start*/}
          <div>{this.props.children}</div>
          {/* Container Section End*/}
          <div className="fixed-bottom">
          {/* Legend Section Start*/}
          <Legend />
          {/* Legend Section End*/}
          {/* Footer Section Start*/}
          <div className="row footer-bg">
           <footer className="footer">
                <span className="text-muted footer-fg mar-l-30px font-size-12px">{appConfig.FOOTER_TEXT}</span>
           </footer>
         </div>
         {/* Footer Section End*/}
       </div>
        </div>);
  }
}

App.contextTypes = {
  router: React.PropTypes.object.isRequired
};

function mapStateToProps(state) {
    return {
    };
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({getNodes}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(App);
