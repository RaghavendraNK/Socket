import * as types from "../constants/actionTypes";
import _ from "lodash";
export default function(state = null, action) {
    switch (action.type) {
        case types.GET_NODES:
              return Object.assign({}, state, {data: action.payload, removeNodes: action.removePayload, count: action.countPayload});
        case types.UPDATE_NODES:{
              let _nodesList =  Object.assign([], state.data);
              if(action.payload && action.payload.length>0){
                _nodesList.push(action.payload);
              }
              return Object.assign({}, state, {data: _.flattenDepth(_nodesList, 1), removeNodes: action.removePayload, count: action.countPayload});}
    }
    return state;
}
