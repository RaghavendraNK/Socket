/* react builtin libraries */
import React, {Component} from "react";
import deepEqual from "deep-equal";
/* redux builtin libraries for connecting the component with action*/
import {connect} from "react-redux";
import {bindActionCreators} from "redux";

/* Make the API Call to get the Nodes */
import {updateNodes, getNodes, getLatestNodes, getInitalNodes} from "../actions/nodesActions";

/*Utility methods to alter the data */
import {filterNodes, getGroup, filterEdges, getNodesData, modifyProps, optimizeNodes} from "../utils/utility";

/* Component to show the Graph */
import Graph from "../components/Graph";

/* Lodash utility library for data manipulation*/
import _ from "lodash";

/* library for socket implementaion */
import openSocket from "socket.io-client";

/* Get the configurations from config file */
import {appConfig} from "../config/appConfig.json";

/* Opening the Socket for particular URL */
const socket = openSocket(appConfig.URL);

/* Graph Configuration Settings */
const  options = appConfig.nodeOptions;

class Home extends Component{
  constructor(props, context){
    super(props, context);
    this.state={
      filteredNodes: null,
      edges: null,
      isInProgress: true,
    };
  }

  isArrayEqual(x, y) {
      return  deepEqual(x, y);
  }

  componentWillReceiveProps(nextProps) {
    if(this.props.nodes && nextProps.nodes && !this.isArrayEqual(this.props.nodes.data, nextProps.nodes.data)){

      this.setState({filteredNodes: modifyProps(nextProps.nodes, nextProps.removeNodes), edges:filterEdges(nextProps.nodes)});
    }
  }

  componentDidMount() {
  socket.on("flag", flag => {
      this.state.isInProgress = flag.data && flag.data._fields[0] && flag.data._fields[0].properties? flag.data._fields[0].properties.value : false;
      let _refresh = flag.data && flag.data._fields[0] && flag.data._fields[0].properties? flag.data._fields[0].properties.refresh : false;
      let _maxIdObj;
      let _nodeList = _.uniqWith(this.state.filteredNodes, _.isEqual);
      /*if(_refresh==false){
        if(!this.state.isInProgress && _nodeList.length == 0){
              console.log("If");
              this.props.getNodes();
        }else if(!this.state.isInProgress){
          console.log("Else If");
          _maxIdObj = _.maxBy((_nodeList), function(o){
              return parseInt(o.id);
          });
          this.props.getLatestNodes(_maxIdObj.id);
        }
      }else if(_refresh==true){
        this.props.getInitalNodes();
      }*/
      this.props.getNodes();
    });
    socket.emit("isInProgressNodesModification", appConfig.SOCKET_TIME_DELAY);
  }

  shouldComponentUpdate(nextProps, nextState){
    if(this.props.nodes && nextProps.nodes && !this.isArrayEqual(this.props.nodes.data, nextProps.nodes.data)){
      return true;
    }
    return false;
  }

  componentDidCatch(error, info){
    console.error(error);
  }

 alterEdges(alterNodes, edges){
   let _edges =  _.uniqWith(edges, _.isEqual);
   _.map(_edges, function(item){
      let _fromPriority = _.find(alterNodes, ['id', item.from]).priority;
      let _toPriority = _.find(alterNodes, ['id', item.to]).priority;
      if(parseInt(_fromPriority)>parseInt(_toPriority)){
        let _from = item.from;
        let _to = item.to;
        item.from = _to;
        item.to = _from;
      }
   });
   return _edges;
 }

  render(){
      let {filteredNodes, edges} = this.state;
      let _alterNodes = _.uniqWith(filteredNodes, _.isEqual);
      const graph = { nodes: _alterNodes, edges: this.alterEdges(_alterNodes, edges) };
      return(<div>
                <div className="row">
                      <div className="col-md-12">
                        {this.state.filteredNodes && <Graph graph={graph} options={options} />}
                      </div>
                </div>
                <div className="row">
                      <div className="col-md-12">
                          <div id="network"  className="height-100-per"></div>
                      </div>
                </div>
          </div>);
   }
}

Home.contextTypes = {
  router: React.PropTypes.object.isRequired
};

function mapStateToProps(state) {
    return {
      nodes: state.nodes? state.nodes: {data:[]},
      removeNodes: state.nodes? state.nodes.removeNodes: [],
    };
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({getLatestNodes, updateNodes, getNodes, getInitalNodes}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(Home);
