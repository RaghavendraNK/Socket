import {SERVICE_URLS} from "../constants/serviceURL";
import * as types from "../constants/actionTypes";
import axios from "axios";
import _ from "lodash";

let config = {
   headers: {
     "Content-Type": "application/json",
     "Access-Control-Allow-Origin": "*",
     "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
   }
 };

let getNodes = () =>{
     const url=SERVICE_URLS.GET_NODES;
     const apiNodesListRequest=axios.get(url, config);
     return(dispatch)=>{
       return apiNodesListRequest.then(({data})=>{
           dispatch({type:types.GET_NODES, payload:data.nodes, removePayload:[], countPayload: data.count});
      }).catch((error)=>{
         throw(error);
      });
   }
}

let suspendOrResume = (flag) => {
  const url=SERVICE_URLS.UPDATE_PAUSE_NODES+ "/" + flag;
  const apiNodesFlagRequest=axios.get(url, config);
  return(dispatch)=>{
    return apiNodesFlagRequest.then(({data})=>{
        ///dispatch({type:types.GET_NODES, payload:datat});
   }).catch((error)=>{
      throw(error);
   });
}
}

let getLatestNodes = (maxId) =>{
   const GETURL=SERVICE_URLS.GET_LATEST_NODES+"/"+maxId;
   const REMOVEURL=SERVICE_URLS.GET_REMOVED_NODES;
    return(dispatch)=>{
        return axios.all([axios.get(GETURL, config), axios.get(REMOVEURL, config)])
        .then(axios.spread(function (addNodes, removeNodes) {
          let _data =_.uniqWith(removeNodes.data.removeNodes, _.isEqual);
           if(_data.length> 0 && _data[0]._fields.length> 0){
             dispatch({type:types.UPDATE_NODES, payload:addNodes.data, removePayload:_data[0]._fields, countPayload: removeNodes.data.count});
          }else{
             dispatch({type:types.UPDATE_NODES, payload:addNodes.data, removePayload: [], countPayload: removeNodes.data.count});
          }
         return;
        })).catch((error)=>{
          throw(error);
       });
   }
}

let updateNodes = (nodes) => {
  return(dispatch)=>{
    dispatch({type:types.GET_NODES, payload:nodes});
  }
}

let getInitalNodes = () =>{
  const GETURL=SERVICE_URLS.GET_INITAL_NODES;
  const REMOVEURL=SERVICE_URLS.GET_REMOVED_NODES;
   return(dispatch)=>{
       return axios.all([axios.get(GETURL, config), axios.get(REMOVEURL, config)])
       .then(axios.spread(function (addNodes, removeNodes) {
         let _data =_.uniqWith(removeNodes.data.removeNodes, _.isEqual);
          if(_data.length> 0 && _data[0]._fields.length> 0){
            dispatch({type:types.GET_NODES, payload:addNodes.data, removePayload:_data[0]._fields, countPayload: removeNodes.data.count});
         }else{
            dispatch({type:types.GET_NODES, payload:addNodes.data, removePayload: [], countPayload: removeNodes.data.count});
         }
        return;
       })).catch((error)=>{
         throw(error);
      });
  }
}
export {getNodes, updateNodes, getLatestNodes, getInitalNodes, suspendOrResume};
