/* react builtin libraries */
import React, {Component} from "react";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
/* Vis library to display the nodes */
import vis from "vis";
import Checkbox from 'react-toolbox/lib/checkbox';

/* Get the configurations from config file */
import {appConfig} from "../config/appConfig.json";

let network;
/* Contains the different node classes */
const nodeList = appConfig.NODE_LIST;
class Graph extends Component{
  constructor(props){
    super(props);
    this.state = {
      graph: props.graph,
      options: props.options,
      isGroupByApplied: "All"

    }
  }

  renderVisNetwork(){
    network = new vis.Network(document.getElementById("network"), this.state.graph, this.state.options);
    network.on("selectNode", function(params) {
        if (params.nodes.length == 1) {
            if (network.isCluster(params.nodes[0]) == true) {
                network.openCluster(params.nodes[0]);
            }
        }
    });
  }

  componentDidMount(){
    this.renderVisNetwork();
  }

  componentWillReceiveProps(nextProps) {
    if(this.props.graph !== nextProps.graph) {
      this.setState({graph: nextProps.graph, isGroupByApplied: "All"});
    }
  }

  getColor(nodeType){
    let {groups} = appConfig.nodeOptions;
    switch(nodeType){
      case "NR": return groups.NR;
      case "SUPI": return groups.SUPI;
      case "RAN": return groups.RAN;
      case "UDM": return groups.UDM;
      case "AUSF": return groups.AUSF;
      case "NRF": return groups.NRF;
      case "SCTP_REDIRECTOR": return groups.SCTP_REDIRECTOR;
      default: return groups.NR;
    }
  }

  groupByClass(nodeType){
    if(nodeType!=this.state.isGroupByApplied){
    let data = this.state.graph;
    let colorObj = this.getColor(nodeType);
    network.setData(data);
      let clusterOptionsByData = {
          joinCondition:function(childOptions) {
              return childOptions.group == nodeType;
          },
          clusterNodeProperties: {id: nodeType, label: nodeType, borderWidth:2, font:{size:30, color: 'white'}, shape:"circle", color: colorObj.color}
      };
      this.setState({isGroupByApplied: nodeType});
      network.cluster(clusterOptionsByData);
    }
    else{
      this.renderVisNetwork();
      this.setState({isGroupByApplied: "All"});
    }
  }

  render(){
    if(this.state.isGroupByApplied=="All"){
        this.renderVisNetwork();
    }
    return(<div className="row">
            <div id="fieldset-grp-div" className="col-md-12">
                <fieldset>
                    <legend>Group By:</legend>
                  <ul>
                    {nodeList && nodeList.map((node, index)=>{
                      if(node!="SCTP"){
                        return(<li key={index}><Checkbox checked={this.state.isGroupByApplied==node?true:false} label={node} onChange={this.groupByClass.bind(this, node)} /></li>)
                      }
                      else {
                        return(<li key={index}><Checkbox checked={this.state.isGroupByApplied=="SCTP_REDIRECTOR"?true:false} label={node} onChange={this.groupByClass.bind(this, "SCTP_REDIRECTOR")} /></li>)
                      }
                    })}
                  </ul>
                </fieldset>
            </div>
          </div>);
  }
}

Graph.contextTypes = {
  router: React.PropTypes.object.isRequired
};

function mapStateToProps(state) {
    return {};
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({}, dispatch);
}

export default connect(mapStateToProps, matchDispatchToProps)(Graph);
