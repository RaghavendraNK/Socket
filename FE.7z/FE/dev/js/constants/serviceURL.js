/* Get the configurations from config file */
import {appConfig} from "../config/appConfig.json";

/// Root URL for the BE(API)
const root = appConfig.URL;

export const SERVICE_URLS = {
  GET_NODES: root + "getNodes",
  GET_LATEST_NODES: root + "getLatestNodes",
  GET_REMOVED_NODES: root + "getRemovedNodes",
  GET_INITAL_NODES: root + "getInitalNodes",
  UPDATE_PAUSE_NODES: root + "updatePause"
};
