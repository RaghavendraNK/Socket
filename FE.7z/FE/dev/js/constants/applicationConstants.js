/// Constant on Which the React DOM should render(Id of the div specified in .html file)
export const APP_CONSTANT = {
  APP: "app"
};
